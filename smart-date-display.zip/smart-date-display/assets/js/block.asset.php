<?php
return array(
    'dependencies' => array(
        'wp-blocks',
        'wp-element',
        'wp-components',
        'wp-i18n',
        'wp-block-editor'
    ),
    'version' => filemtime(plugin_dir_path(__FILE__) . 'smart-date-admin.js'),
);